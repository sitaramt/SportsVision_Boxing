
文件说明如下：

1、record.txt   （SDK 更新记录）

2、fitblekit_aar  （SDK .arr 架包，.arr或.jar 架包根据需求使用一种即可）

3、fitblekit_jar  （SDK .jar 架包，.arr或.jar 架包根据需求使用一种即可）

4、fitblekitdemo  （SDK Demo）

5、sdk document（SDK说明文档）